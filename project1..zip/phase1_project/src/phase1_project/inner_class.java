package phase1_project;
//MEMEBR INNER CLASS
/*class Outer {
    private int a = 25;

    class Inner {
        void display() {
            System.out.println("it's a inner class : " + a);
        }
    }
}*/
//Static nested class
/*class Outer {
    static class StaticInner {
        void display() {
            System.out.println("Static nested Class");
        }
    }
}*/
//local inner class
class Outer {
    void outerMethod() {
        class LocalInner {
            void display() {
                System.out.println("Local Inner Class");
            }
        }

        LocalInner inner = new LocalInner();
        inner.display();
    }
}

public class inner_class {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*  Outer outer = new Outer();
	        Outer.Inner inner = outer.new Inner();
	        inner.display();*/
		/* Outer.StaticInner inner = new Outer.StaticInner();
	        inner.display();*/
		Outer outer = new Outer();
        outer.outerMethod();
	}

}
