package phase1_project;
/*class calculate{
	int mul(int a,int b) {
		return a*b;
	}
}*/
 class xyz1 {
	  
    
    private int number;
    private String name;
  
    
    public int getNumber() { 
    	return number; 
    	}
  
    public String getName() { 
    	return name;
    	}
 
    public void setNumber(int number)
    {
        this.number = number;
    }
  
    public void setName(String name) { 
    	this.name = name;
    	}
  
   
    public void printDetails()
    {
        System.out.println("Number: " + number);
        System.out.println("Name: " + name);
    }
}
public class method {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	/*	calculate m = new calculate();
		int c=m.mul(5, 4);
		System.out.println(c);*/
		xyz1 example = new xyz1();
		example.setNumber(123);
		example.setName("Comapny Employee");
		example.printDetails();

	}

}
