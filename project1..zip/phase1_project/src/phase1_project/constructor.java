package phase1_project;
//default constructor
/*class xyz3{
	xyz3(){
		System.out.println("it's a default constructor");
	}
}*/
//parameterized constructor
class xyz4{
	xyz4(String s,int a){
		System.out.println(s+" "+a);
	}
}

public class constructor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       /* xyz3 obj3= new xyz3();*/
		xyz4 obj4 =new xyz4("Pawan",25);
		
	}

}
