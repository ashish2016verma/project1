package phase1_project;
import java.util.*;
public class array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Scanner sc =new Scanner(System.in);
      System.out.println("inter a length:");
      int n=sc.nextInt();
      int [] arr=new int[n];
      System.out.println("user number:");
      for(int i=0;i<n;i++) {
    	   arr[i]=sc.nextInt();
      }
      System.out.println("output is:");
      for(int i= 0;i<n;i++) {
    	  System.out.print(arr[i]+" ");
      }
      System.out.println("sort a array");
      Arrays.sort(arr);
      for(int x:arr) {
    	  System.out.println(x);
      }
	}

}
