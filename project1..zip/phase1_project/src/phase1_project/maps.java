package phase1_project;
import java.util.*;
public class maps {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  Map<Integer,String> map=new HashMap<Integer,String>();  
		  map.put(10,"Amit");  
		  map.put(11,"Vijay");  
		  map.put(12,"Rahul");  
		  //Elements can traverse in any order  
		  for(Map.Entry m:map.entrySet()){  
		   System.out.println(m.getKey()+" "+m.getValue());  
		  }  

	}

}
