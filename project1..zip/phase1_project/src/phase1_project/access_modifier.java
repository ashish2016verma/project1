package phase1_project;
class xyz{
	public int x=10;
	protected int y=20;
	//private int z=30;
	public void a() {
		System.out.println(x);
	}
}


public class access_modifier {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      xyz b=new xyz();
      b.a();
      System.out.println(b.y);
      //we can't access private in public.
      //System.out.println(b.z);
      
	}

}
