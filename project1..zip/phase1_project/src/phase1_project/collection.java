package phase1_project;
import java.util.*;
public class collection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		   int arr[] = new int[] { 1, 2, 3, 4 };
	        Vector<Integer> v = new Vector<Integer>();
	        v.addElement(1);
	        v.addElement(10);
	        System.out.println(arr[3]);
	        System.out.println(v.elementAt(0));
	     
	 
	        

	}

}
