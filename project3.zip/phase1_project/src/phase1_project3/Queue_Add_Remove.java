package phase1_project3;
import java.util.*;

public class Queue_Add_Remove {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Queue<Integer> q = new PriorityQueue<Integer> (); 
		  int n=5;
		  for(int i=0;i<n;i++)
		  {
			  q.add(i);
		  }
		  System.out.println("Before Adding Element");
		  System.out.println(q);
		  q.add(55);
		  System.out.println("After Adding Element");
		  System.out.println(q);
		  System.out.println("Afetr Removing Element");
		  q.remove();
		  System.out.println(q);
	}

}
