package phase1_project3;
import java.util.*;

public class Unsorted_Element {

	public static void main(String[] args) {
		try (// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter a number");
			int n= sc.nextInt();
			System.out .println("Enter number");
			int[] arr=new int[n];
			for(int i=0;i<n;i++)
			{
				arr[i]=sc.nextInt();
			}
			Arrays.sort(arr);
			int k=4;
			System.out.println("Element 4th smallest no:");
				System.out.println(arr[k-1]);
		}
	    
	    
	}

}
