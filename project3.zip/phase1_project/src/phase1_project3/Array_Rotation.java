package phase1_project3;
import java.util.*;

public class Array_Rotation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 List<Integer> l= new ArrayList<>();
	        l.add(10);
	        l.add(20);
	        l.add(30);
	        l.add(40);
	        l.add(50);
	        l.add(60);
	        l.add(70);
	        System.out.println("before rotation");
	       for(int i=0;i<l.size();i++)
	       {
	    	   System.out.println(l.get(i));
	       }
	  
	        Collections.rotate(l, 5);
	  
	      System.out.println("After rotation");
	       for(int i=0;i<l.size();i++){
	    	   System.out.println(l.get(i));
	       }

	}

}
