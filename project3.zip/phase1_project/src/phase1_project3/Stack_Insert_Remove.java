package phase1_project3;
import java.util.*;

public class Stack_Insert_Remove {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Stack<Integer> S=new Stack<Integer>();
       //Adding Element
       S.push(5);
       S.push(10);
       S.push(15);
       System.out.println("Before Adding:");
       System.out.println(S);
       System.out.println("After Adding Element:");
       S.push(50);
       System.out.println(S);
       //Removing Element
       S.pop();
       System.out.println("After removing eleemnt:");
       System.out.println(S);
	}

}
