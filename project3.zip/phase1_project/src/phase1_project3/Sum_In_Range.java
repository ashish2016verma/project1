package phase1_project3;
import java.util.*;
public class Sum_In_Range {

	public static void main(String[] args) {
		try (// TODO Auto-generated method stub
	Scanner sc = new Scanner(System.in)) {
		System.out.println("Enter a number");
		  int n=sc.nextInt();
		  System.out.println("Enter an Element");
		  int[] ar=new int[n];
		  for(int i=0;i<n;i++)
		  {
			  ar[i]=sc.nextInt();
		  }
		  int sum=0;
		  System.out.println("Enter a number for L");
		 int l=sc.nextInt();
		 System.out.println("Enter a number for M");
		 int m=sc.nextInt();
		 for(int i=0;i<n;i++)
		 {
			 if(0<=l&&l<=m&&m<=n-1 )
			 {
				
				 sum+=ar[i];
				
			 }
			 else
			 {
				 System.out.println("invailid Number");
				 break;
			 }
		 }
		 System.out.println("The sum is :"+ sum);
	}
	}

}
