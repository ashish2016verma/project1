package phase1_project4;
import java.util.*;

public class Binary_Search {
	static int binarySearch(int arr[],int l,int r,int x)
	{
		while (l <= r) {
            int mid = (l + r) / 2;
            if (arr[mid] == x) {
                return mid;
            } else if (arr[mid] > x)
            {
                r = mid - 1;
            } else
            {
              l = mid + 1;
            } 
        }
 
        return -1;
	}

	public static void main(String[] args) {
		try (// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter length of Array:");
			int n=sc.nextInt();
			System.out.println("Enter a array Number:");
			int[] arr=new int[n];
			for(int i=0;i<n;i++)
			{
				arr[i]=sc.nextInt();
			}
			System.out.println("Enter a number for search:");
			int x=sc.nextInt();
			int res=binarySearch(arr,0,n-1,x);
			if(res==-1)
			{
				System.out.println("Number is not found");
			}
			else
			{
				System.out.println("Number found at index:");
				System.out.println(+res);
			}
		}

	}

}
