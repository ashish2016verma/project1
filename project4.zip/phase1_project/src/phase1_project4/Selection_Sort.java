package phase1_project4;

import java.util.*;

public class Selection_Sort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j,temp;
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter length of Array:");
			int n=sc.nextInt();
			System.out.println("Enter a array Number:");
			int[] arr=new int[n];
			for( i=0;i<n;i++)
			{
				arr[i]=sc.nextInt();
			}
			System.out.print("Sorting Array using Selection Sort Technique..\n");  
			   for(i=0; i<n; i++)  
			   {  
			       for(j=i+1; j<n; j++)  
			       {  
			           if(arr[i] > arr[j])  
			           {  
			               temp = arr[i];  
			               arr[i] = arr[j];  
			               arr[j] = temp;  
			           }  
			       }  
			   }  
			   System.out.print("Now the Array after Sorting is :\n");  
			   for(i=0; i<n; i++)  
			   {  
			       System.out.print(arr[i]+ "  ");  
			   }
		}  
	}

}
