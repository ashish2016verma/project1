package phase1_project4;
import java.util.*;

public class Exponential_Search {
	static int  exponentialSearch(int arr[],int n,int x)
	{
		 if (arr[0] == x)
	            return 0;
	        int i = 1;
	        while (i < n && arr[i] <= x)
	            i = i*2;
	        return Arrays.binarySearch(arr, i/2,
	                              Math.min(i, n-1), x);
	    }
	

	public static void main(String[] args) {
		try (// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter length of Array:");
			int n=sc.nextInt();
			System.out.println("Enter a array Number:");
			int[] arr=new int[n];
			for(int i=0;i<n;i++)
			{
				arr[i]=sc.nextInt();
			}
			System.out.println("Enter a number for search:");
			int x=sc.nextInt();
			int res= exponentialSearch(arr,n,x);
			if(res==-1)
			{
				System.out.println("Number is not found");
			}
			else
			{
				System.out.println("Number found at index:");
				System.out.println(+res);
			}
		}
		

	}

}
