package phase1_project4;
import java.util.*;

public class Linear_Search {
	static int search(int arr[],int n,int x)
	{
		for(int i = 0; i < n; i++) {
            
            if (arr[i] == x)
                return i;
        }
 
        return -1;
    }
	

	public static void main(String[] args) {
		try (// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter a length");
			int n=sc.nextInt();
			System.out.println("Enter Array Element:");
			int [] arr=new int[n];
			for(int i=0;i<n;i++) 
			{
				arr[i]=sc.nextInt();
			}
			System.out.println("Enetr  a number for linear search:");
			int x=sc.nextInt();
			int index = search(arr,n,x);
			if(index==-1)
			{
				System.out.println("Number is not present in array");
			}
			else
			{
				System.out.println("Number is found at index");
				System.out.print(+ index);
			}
		}
         
	}

}
