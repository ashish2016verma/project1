package phase1_project4;

public class mergeSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int[] array = {12, 11, 13, 5, 6, 7};

	        System.out.println("Original array:");
	        printArray(array);

	        mergeSort(array);

	        System.out.println("Sorted array:");
	        printArray(array);
	    }

	    public static void mergeSort(int[] array) {
	        int n = array.length;
	        if (n < 2) {
	            return;
	        }

	        int mid = n / 2;
	        int[] leftArray = new int[mid];
	        int[] rightArray = new int[n - mid];

	        // Populate left and right sub-arrays
	        for (int i = 0; i < mid; i++) {
	            leftArray[i] = array[i];
	        }
	        for (int i = mid; i < n; i++) {
	            rightArray[i - mid] = array[i];
	        }

	        // Recursive calls to mergeSort for left and right sub-arrays
	        mergeSort(leftArray);
	        mergeSort(rightArray);

	        // Merge the two sorted sub-arrays
	        merge(array, leftArray, rightArray);
	    }

	    public static void merge(int[] array, int[] leftArray, int[] rightArray) {
	        int leftSize = leftArray.length;
	        int rightSize = rightArray.length;
	        int i = 0, j = 0, k = 0;

	        while (i < leftSize && j < rightSize) {
	            if (leftArray[i] <= rightArray[j]) {
	                array[k] = leftArray[i];
	                i++;
	            } else {
	                array[k] = rightArray[j];
	                j++;
	            }
	            k++;
	        }

	        // Copy remaining elements of leftArray and rightArray (if any)
	        while (i < leftSize) {
	            array[k] = leftArray[i];
	            i++;
	            k++;
	        }
	        while (j < rightSize) {
	            array[k] = rightArray[j];
	            j++;
	            k++;
	        }
	    }

	    public static void printArray(int[] array) {
	        for (int value : array) {
	            System.out.print(value + " ");
	        }
	        System.out.println();

	}

}
