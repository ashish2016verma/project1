package phase1_project2;

public class Try_Catch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//show error and it catch
		/*int a=10;
		int b=0;
		try {
			int S=a/b;
			System.out.println(S);

		
		}catch(Exception e) {
			System.out.println(e);
			System.out.println("Something error");
		}*/
		//no error
		int a=10;
		int b=5;
		try {
			int S=a/b;
			System.out.println(S);

		
		}catch(Exception e) {
			System.out.println(e);
			System.out.println("Something error");
		}
		
	}

}
