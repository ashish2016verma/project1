package phase1_project2;

class Person {
	   
    private String name;
    private int age;

  
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        if (age >= 0) { 
            this.age = age;
        }
    }


    public void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
    }
}


class Student extends Person {
    private int studentId;

    public Student(String name, int age, int studentId) {
        super(name, age); 
        this.studentId = studentId;
    }


    @Override
    public void displayInfo() {
        super.displayInfo(); 
        System.out.println("Student ID: " + studentId);
    }
}


public class piller_oops {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person person = new Person("hunter", 30);
        Student student = new Student("Mahesh", 20, 12345);

        System.out.println("Person Information:");
        person.displayInfo();
        
        System.out.println("\nStudent Information:");
        student.displayInfo();

	}

}
