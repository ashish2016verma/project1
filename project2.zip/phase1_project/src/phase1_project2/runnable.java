package phase1_project2;

class mythread implements Runnable{
	public void run() {
		 
			System.out.println("i'm runnable thread");
			
			System.out.println("i'm runnable thread");
			System.out.println("i'm runnable thread");
			System.out.println("i'm runnable thread");
			
	}
	
}
class mythread2 implements Runnable{
	public void run() {
		     System.out.println("Also i'm Runnable thread");
			System.out.println("Also i'm Runnable thread");
			System.out.println("Also i'm Runnable thread");
			System.out.println("Also i'm Runnable thread");
				
	}
}

public class runnable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		mythread th = new mythread();
		Thread gun1 = new Thread(th);
		mythread2 th1 = new mythread2();
		Thread gun2 = new Thread(th1);
		gun1.start();
		gun2.start();
		

	}

}
