package com.hibernate.apps;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hibernate.entities.Person;

public class PersonAdd {

	public static void main(String[] args)  {
		// TODO Auto-generated method stub
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction trans = session.beginTransaction();
		
		Person person = new Person();
		person.setPersonid(1001);
		person.setPersonName("xyz");
		person.setEmail("abc@gmail.com");
		person.setPhoneno(9900123456L);

		session.save(person); 
		trans.commit();  
		
		System.out.println("Data Saved.....");
		
		session.close();
		sf.close();

	}

}




